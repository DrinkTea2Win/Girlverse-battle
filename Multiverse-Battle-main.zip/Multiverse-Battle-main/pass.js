// ========== МУЛЬТИВЕРС ПАСС v1.4 ==========
// + очки силы ⚡ в наградах (включая бывшие "скорость арены")
// + фикс скролла после получения награды

let passData = {
    currentTier: 1,
    passExp: 0,
    claimedTiers: []
};

const passRewards = [
    { name: "3 обычные карты", icon: "⚪⚪⚪", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Обычная"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("⚪ +3 обычные карты!", "#fff"); } },
    { name: "100 ⭐", icon: "⭐", apply() { points += Math.floor(100 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +100 звёзд!", "#f5af19"); } },
    { name: "Урон x1.3 на 30 мин", icon: "💪", apply() { activeBuffs["dmg13"] = Date.now() + 1800000; saveAll(); renderActiveBuffs(); updatePlayerStats(); showFloatingText("💪 Урон x1.3 на 30 мин!", "#e74c3c"); } },
    { name: "1 редкая карта", icon: "🔵", apply() { let card = createCard("Редкая"); if (card) { myCards.push(card); saveAll(); renderMyCards(); } showFloatingText("🔵 Редкая карта!", "#17a2b8"); } },
    { name: "50 ⚡ СИЛЫ", icon: "⚡", apply() { addPowerPoints(50); showFloatingText("⚡ +50 СИЛЫ!", "#ffd700"); } },
    { name: "200 ⭐", icon: "⭐", apply() { points += Math.floor(200 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +200 звёзд!", "#f5af19"); } },
    { name: "Звёзды x2 на 15 мин", icon: "🌟", apply() { activeBuffs["doubleStars"] = Date.now() + 900000; saveAll(); renderActiveBuffs(); showFloatingText("🌟 Звёзды x2 на 15 мин!", "#f5af19"); } },
    { name: "2 обычные карты", icon: "⚪⚪", apply() { for (let i = 0; i < 2; i++) { let card = createCard("Обычная"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("⚪ +2 обычные карты!", "#fff"); } },
    { name: "1 эпическая карта", icon: "🟣", apply() { let card = createCard("Эпик"); if (card) { myCards.push(card); saveAll(); renderMyCards(); } showFloatingText("🟣 Эпическая карта!", "#9b59b6"); } },
    { name: "100 ⚡ СИЛЫ", icon: "⚡", apply() { addPowerPoints(100); showFloatingText("⚡ +100 СИЛЫ!", "#ffd700"); } },
    { name: "300 ⭐", icon: "⭐", apply() { points += Math.floor(300 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +300 звёзд!", "#f5af19"); } },
    { name: "Урон x2 на 15 мин", icon: "💥", apply() { activeBuffs["doubleDamage"] = Date.now() + 900000; saveAll(); renderActiveBuffs(); updatePlayerStats(); showFloatingText("💥 Урон x2 на 15 мин!", "#e74c3c"); } },
    { name: "2 редкие карты", icon: "🔵🔵", apply() { for (let i = 0; i < 2; i++) { let card = createCard("Редкая"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("🔵 +2 редкие карты!", "#17a2b8"); } },
    { name: "1 мифическая карта", icon: "🔴", apply() { let card = createCard("Мифическая"); if (card) { myCards.push(card); saveAll(); renderMyCards(); } showFloatingText("🔴 Мифическая карта!", "#e74c3c"); } },
    { name: "150 ⚡ СИЛЫ", icon: "⚡", apply() { addPowerPoints(150); showFloatingText("⚡ +150 СИЛЫ!", "#ffd700"); } },
    { name: "500 ⭐", icon: "⭐", apply() { points += Math.floor(500 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +500 звёзд!", "#f5af19"); } },
    // ★ БЫЛО "Скорость арены x3 на 10 мин" → СТАЛО 500 ⚡ ★
    { name: "500 ⚡ СИЛЫ", icon: "⚡", apply() { addPowerPoints(500); showFloatingText("⚡ +500 СИЛЫ!", "#ffd700"); } },
    { name: "3 сверхредкие карты", icon: "🟢🟢🟢", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Сверх редкая"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("🟢 +3 сверхредкие карты!", "#28a745"); } },
    { name: "Препарат V (бесплатно)", icon: "💉", apply() { if (typeof showCompoundVModalFree === 'function') showCompoundVModalFree(); showFloatingText("💉 Бесплатный Препарат V!", "#9b59b6"); } },
    { name: "200 ⚡ СИЛЫ + 200⭐", icon: "⚡", apply() { addPowerPoints(200); points += Math.floor(200 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⚡ +200 СИЛЫ и +200⭐!", "#ffd700"); } },
    { name: "2 легендарных токена", icon: "🎰🎰", apply() { legendaryGachaTokens = (legendaryGachaTokens || 0) + 2; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("🎰 +2 легендарных токена!", "#ffd700"); } },
    { name: "Звёзды x3 на 20 мин", icon: "🌟", apply() { activeBuffs["tripleStars"] = Date.now() + 1200000; saveAll(); renderActiveBuffs(); showFloatingText("🌟 Звёзды x3 на 20 мин!", "#f5af19"); } },
    { name: "1 легендарная крутка", icon: "🟡", apply() { let card = createCard("Легендарная"); if (card) { myCards.push(card); saveAll(); renderMyCards(); sfxCardObtain(); if (typeof startPassGachaAnimation === 'function') startPassGachaAnimation(card, "legendary"); } showFloatingText("🟡 Легендарная крутка!", "#ffd700"); } },
    { name: "1000 ⭐", icon: "⭐", apply() { points += Math.floor(1000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +1000 звёзд!", "#f5af19"); } },
    { name: "300 ⚡ СИЛЫ", icon: "⚡", apply() { addPowerPoints(300); showFloatingText("⚡ +300 СИЛЫ!", "#ffd700"); } },
    { name: "Иммунитет к усталости на 1 час", icon: "🛡️", apply() { activeBuffs["fatigueImmune"] = Date.now() + 3600000; saveAll(); renderActiveBuffs(); showFloatingText("🛡️ Иммунитет 1 час!", "#2ecc71"); } },
    { name: "3 мифические карты", icon: "🔴🔴🔴", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Мифическая"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("🔴 +3 мифические карты!", "#e74c3c"); } },
    { name: "Пальцы Сукуны (бесплатно)", icon: "🗿", apply() { hasSukunaFingers = true; saveAll(); renderShop(); updatePlayerStats(); if (typeof showSukunaModal === 'function') showSukunaModal(); showFloatingText("🗿 Бесплатные Пальцы Сукуны!", "#ff4444"); } },
    { name: "1500 ⭐", icon: "⭐", apply() { points += Math.floor(1500 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +1500 звёзд!", "#f5af19"); } },
    { name: "400 ⚡ СИЛЫ + 2 легендарные крутки", icon: "⚡", apply() { addPowerPoints(400); for (let i = 0; i < 2; i++) { let card = createCard("Легендарная"); if (card) { myCards.push(card); sfxCardObtain(); setTimeout(() => { if (typeof startPassGachaAnimation === 'function') startPassGachaAnimation(card, "legendary"); }, i * 1500); } } legendaryGachaTokens = (legendaryGachaTokens || 0) + 1; saveAll(); renderMyCards(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("⚡ +400 СИЛЫ + 2 крутки!", "#ffd700"); } },
    { name: "Урон x4 на 10 мин", icon: "💥", apply() { activeBuffs["quadDamage"] = Date.now() + 600000; saveAll(); renderActiveBuffs(); updatePlayerStats(); showFloatingText("💥 Урон x4 на 10 мин!", "#ff0000"); } },
    { name: "2 секретных токена", icon: "💎💎", apply() { secretGachaTokens = (secretGachaTokens || 0) + 2; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("💎 +2 секретных токена!", "#ff00ff"); } },
    { name: "2000 ⭐", icon: "⭐", apply() { points += Math.floor(2000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +2000 звёзд!", "#f5af19"); } },
    { name: "1 секретная крутка", icon: "💎", apply() { let card = createCard("Секретная"); if (card) { myCards.push(card); saveAll(); renderMyCards(); sfxCardObtain(); if (typeof startPassGachaAnimation === 'function') startPassGachaAnimation(card, "secret"); } showFloatingText("💎 Секретная крутка!", "#ff00ff"); } },
    // ★ БЫЛО "Скорость арены x5 на 5 мин" → СТАЛО 750 ⚡ ★
    { name: "750 ⚡ СИЛЫ", icon: "⚡", apply() { addPowerPoints(750); showFloatingText("⚡ +750 СИЛЫ!", "#ffd700"); } },
    { name: "3 эпические + 500 ⭐", icon: "🟣🟣🟣", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Эпик"); if (card) myCards.push(card); } points += Math.floor(500 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderMyCards(); renderPoints(); showFloatingText("🟣 +3 эпика + 500⭐!", "#9b59b6"); } },
    { name: "500 ⚡ СИЛЫ + 3 легендарных токена", icon: "⚡", apply() { addPowerPoints(500); legendaryGachaTokens = (legendaryGachaTokens || 0) + 3; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("⚡ +500 СИЛЫ + 3 токена!", "#ffd700"); } },
    { name: "Двойной опыт на 30 мин", icon: "📊", apply() { activeBuffs["doubleExp"] = Date.now() + 1800000; saveAll(); renderActiveBuffs(); showFloatingText("📊 Двойной опыт на 30 мин!", "#f5af19"); } },
    { name: "Легендарная крутка + V", icon: "🟡💉", apply() { let card = createCard("Легендарная"); if (card) { myCards.push(card); sfxCardObtain(); if (typeof startPassGachaAnimation === 'function') startPassGachaAnimation(card, "legendary"); } if (typeof showCompoundVModalFree === 'function') showCompoundVModalFree(); saveAll(); renderMyCards(); showFloatingText("🟡 Легендарная крутка + V!", "#ffd700"); } },
    { name: "3000 ⭐", icon: "⭐", apply() { points += Math.floor(3000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +3000 звёзд!", "#f5af19"); } },
    { name: "3 секретных токена", icon: "💎💎💎", apply() { secretGachaTokens = (secretGachaTokens || 0) + 3; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("💎 +3 секретных токена!", "#ff00ff"); } },
    { name: "Мега-бафф на 15 мин", icon: "🔥", apply() { activeBuffs["doubleDamage"] = Date.now() + 900000; activeBuffs["doubleStars"] = Date.now() + 900000; activeBuffs["arenaSpeedX2"] = Date.now() + 900000; saveAll(); renderActiveBuffs(); updatePlayerStats(); showFloatingText("🔥 Урон x2 + Звёзды x2 + Скорость x2!", "#ff4400"); } },
    { name: "5 мифических карт", icon: "🔴🔴🔴🔴🔴", apply() { for (let i = 0; i < 5; i++) { let card = createCard("Мифическая"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("🔴 +5 мифических карт!", "#e74c3c"); } },
    { name: "Огонь Дома (бесплатно)", icon: "🔥", apply() { hasFireArtifact = true; saveAll(); renderShop(); showFloatingText("🔥 Бесплатный Огонь Дома!", "#ff6b6b"); } },
    { name: "5000 ⭐", icon: "⭐", apply() { points += Math.floor(5000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +5000 звёзд!", "#f5af19"); } },
    { name: "5 легендарных токенов", icon: "🎰🎰🎰🎰🎰", apply() { legendaryGachaTokens = (legendaryGachaTokens || 0) + 5; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("🎰 +5 легендарных токенов!", "#ffd700"); } },
    { name: "Неуязвимость на арене 1 мин", icon: "🛡️", apply() { activeBuffs["arenaInvuln"] = Date.now() + 60000; saveAll(); renderActiveBuffs(); showFloatingText("🛡️ Неуязвимость 1 мин!", "#ffd700"); } },
    { name: "2 секретные карты", icon: "💎💎", apply() { for (let i = 0; i < 2; i++) { let card = createCard("Секретная"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("💎 +2 секретные карты!", "#ff00ff"); } },
    { name: "3 легендарные крутки + 2000⭐", icon: "🟡🟡🟡", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Легендарная"); if (card) { myCards.push(card); sfxCardObtain(); setTimeout(() => { if (typeof startPassGachaAnimation === 'function') startPassGachaAnimation(card, "legendary"); }, i * 1500); } } points += Math.floor(2000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderMyCards(); renderPoints(); showFloatingText("🟡 +3 легендарные крутки + 2000⭐!", "#ffd700"); } },
    { name: "5 секретных токенов", icon: "💎💎💎💎💎", apply() { secretGachaTokens = (secretGachaTokens || 0) + 5; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("💎 +5 секретных токенов!", "#ff00ff"); } },
    { name: "Скип следующего боя", icon: "⏭️", apply() { skipUsed = false; deathNoteTarget = wave; saveAll(); showFloatingText("⏭️ Следующий бой пропущен!", "#ffaa00"); } },
    { name: "10 мифических карт", icon: "🔴x10", apply() { for (let i = 0; i < 10; i++) { let card = createCard("Мифическая"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("🔴 +10 мифических карт!", "#e74c3c"); } },
    { name: "3 Препарата V", icon: "💉💉💉", apply() { if (typeof showCompoundVModalFree === 'function') { showCompoundVModalFree(); setTimeout(() => showCompoundVModalFree(), 500); setTimeout(() => showCompoundVModalFree(), 1000); } showFloatingText("💉 +3 Препарата V!", "#9b59b6"); } },
    { name: "10000 ⭐", icon: "⭐", apply() { points += Math.floor(10000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +10000 звёзд!", "#f5af19"); } },
    { name: "5 секретных + 5 лег. токенов", icon: "💎🎰", apply() { secretGachaTokens = (secretGachaTokens || 0) + 5; legendaryGachaTokens = (legendaryGachaTokens || 0) + 5; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("💎🎰 +5 +5 токенов!", "#ff00ff"); } },
    { name: "Бесконечная выносливость 1 час", icon: "🛡️", apply() { fatigue = 0; activeBuffs["fatigueImmune"] = Date.now() + 3600000; saveAll(); updateFatigue(); renderActiveBuffs(); showFloatingText("🛡️ Усталость 0 на 1 час!", "#2ecc71"); } },
    { name: "3 секретные карты", icon: "💎💎💎", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Секретная"); if (card) myCards.push(card); } saveAll(); renderMyCards(); showFloatingText("💎 +3 секретные карты!", "#ff00ff"); } },
    { name: "20000 ⭐", icon: "⭐", apply() { points += Math.floor(20000 * getStarMult()); if (points > maxPoints) maxPoints = points; saveAll(); renderPoints(); showFloatingText("⭐ +20000 звёзд!", "#f5af19"); } },
    { name: "5 секретных + 10 лег. токенов", icon: "💎🎰", apply() { secretGachaTokens = (secretGachaTokens || 0) + 5; legendaryGachaTokens = (legendaryGachaTokens || 0) + 10; saveAll(); if (typeof renderGachaTab === 'function') renderGachaTab(); showFloatingText("💎🎰 +5 +10 токенов!", "#ff00ff"); } },
    { name: "3 БЕСПЛАТНЫЕ СЕКРЕТНЫЕ КРУТКИ!", icon: "🎉", apply() { for (let i = 0; i < 3; i++) { let card = createCard("Секретная"); if (card) { myCards.push(card); sfxCardObtain(); setTimeout(() => { if (typeof startPassGachaAnimation === 'function') startPassGachaAnimation(card, "secret"); }, i * 2000); } } saveAll(); renderMyCards(); showFloatingText("🎉 3 СЕКРЕТНЫЕ КРУТКИ!", "#ff00ff"); setTimeout(() => { alert("🎉 ПОЗДРАВЛЯЕМ! 🎉\n\nВы завершили Мультиверс Пасс!\nПолучено 3 бесплатные секретные крутки!\n\nСпасибо за игру!"); }, 6500); } }
];

// ★ ФИКС: сохраняем позицию скролла ДО перерисовки и восстанавливаем ПОСЛЕ ★
let _passScrollPosition = 0;

function savePassScroll() {
    let container = document.getElementById("passTiersList");
    if (container) _passScrollPosition = container.scrollTop;
}

function restorePassScroll() {
    let container = document.getElementById("passTiersList");
    if (container) container.scrollTop = _passScrollPosition;
}

function getPassExpNeeded(tier) {
    return Math.floor((10 + Math.pow(tier - 1, 1.5) * 3) * 5);
}

function addPassExp(amount) {
    if (!passData) return;
    if (activeBuffs["doubleExp"] && activeBuffs["doubleExp"] > Date.now()) {
        amount *= 2;
    }
    passData.passExp += amount;
    while (passData.currentTier < 60) {
        let needed = getPassExpNeeded(passData.currentTier);
        if (passData.passExp >= needed) {
            passData.passExp -= needed;
            passData.currentTier++;
            showFloatingText("🎫 Пасс: этап " + passData.currentTier + "!", "#ffd700");
        } else {
            break;
        }
    }
    saveAll();
    renderPass();
}

function startPassGachaAnimation(card, type) {
    let availableRarities = [];
    switch(type) {
        case "legendary": availableRarities = ["Мифическая", "Легендарная", "Секретная"]; break;
        case "secret": availableRarities = ["Легендарная", "Секретная"]; break;
        default: availableRarities = ["Эпик", "Мифическая", "Легендарная"];
    }
    let fakeCards = [];
    for (let i = 0; i < 8; i++) {
        let randomRarity = availableRarities[Math.floor(Math.random() * availableRarities.length)];
        let fc = createCard(randomRarity);
        if (fc) fakeCards.push(fc);
    }
    fakeCards.push(card);
    
    let modalContent = document.getElementById("modalContent");
    let modalOverlay = document.getElementById("modalOverlay");
    if (!modalContent || !modalOverlay) return;
    modalOverlay.style.display = "flex";
    
    let index = 0;
    let totalFlashes = 20;
    let flashCount = 0;
    let speed = 80;
    
    function flashNextCard() {
        if (flashCount >= totalFlashes) {
            modalContent.innerHTML = '<h2>🎰 Выпала карта!</h2>' + getCardResultHTML(card) + '<button class="btn btn-primary" style="width:100%;padding:12px;margin-top:15px;" onclick="closeModal()">ЗАБРАТЬ</button>';
            return;
        }
        let currentCard = fakeCards[index % fakeCards.length];
        let rarityColor = typeof getRarityColor === 'function' ? getRarityColor(currentCard.rarity) : "#fff";
        modalContent.innerHTML = '<h2>🎰 Крутка Пасса...</h2>' +
            '<div style="text-align:center;padding:10px;">' +
            '<div style="font-size:48px;margin-bottom:10px;">🎴</div>' +
            '<div style="font-size:28px;font-weight:900;color:' + rarityColor + ';text-shadow: 0 0 20px ' + rarityColor + ';margin-bottom:8px;">' + (typeof escapeHtml === 'function' ? escapeHtml(currentCard.name) : currentCard.name) + '</div>' +
            '<div class="rarity-tag ' + (typeof rarityColors !== 'undefined' ? rarityColors[currentCard.rarity] : '') + '" style="font-size:16px;padding:8px 20px;">' + currentCard.rarity + '</div>' +
            '<div style="margin-top:12px;font-size:16px;">💪 ' + currentCard.damage + ' ❤️ ' + currentCard.hp + '</div>' +
            '</div>' +
            '<button class="btn" style="width:100%;padding:8px;margin-top:10px;background:#e74c3c;border:none;color:white;font-weight:bold;" onclick="closeModal()">⏭️ ПРОПУСТИТЬ</button>';
        index++;
        flashCount++;
        if (flashCount > totalFlashes * 0.7) speed += 40;
        else if (flashCount > totalFlashes * 0.5) speed += 20;
        else if (flashCount > totalFlashes * 0.3) speed += 10;
        setTimeout(flashNextCard, speed);
    }
    flashNextCard();
}

function claimPassReward(tier) {
    if (tier < 1 || tier > 60) return;
    if (tier > passData.currentTier && (mode !== "moder" || !moderUnlocked)) {
        alert("🔒 Этот этап ещё не открыт! Нужно набрать больше опыта.");
        return;
    }
    if (passData.claimedTiers.includes(tier)) {
        alert("✅ Вы уже получили награду за этот этап!");
        return;
    }
    // ★ СОХРАНЯЕМ ПОЗИЦИЮ СКРОЛЛА ★
    savePassScroll();
    
    let reward = passRewards[tier - 1];
    reward.apply();
    passData.claimedTiers.push(tier);
    saveAll();
    renderPass();
    
    // ★ ВОССТАНАВЛИВАЕМ ПОЗИЦИЮ СКРОЛЛА ПОСЛЕ ПЕРЕРИСОВКИ ★
    setTimeout(function() { restorePassScroll(); }, 0);
    
    if (tier === 60) {
        setTimeout(() => {
            alert("🎉 ПОЗДРАВЛЯЕМ! 🎉\n\nВы завершили Мультиверс Пасс!\nВсе 60 этапов пройдены!\n\nВы настоящий герой мультивселенной!");
        }, 7000);
    }
}

function resetPass() {}

function showCompoundVModalFree() {
    let html = '<h2>💉 Бесплатный Препарат V</h2><div style="max-height:300px;overflow-y:auto;">';
    if (!team.length) {
        html += '<p style="color:#888;">Нет героев в команде.</p>';
    } else {
        team.forEach((idx, s) => {
            let cd = myCards[idx];
            if (!cd) return;
            let hasV = hasCompoundV[cd.name] || false;
            html += '<div class="team-select-item ' + (hasV ? 'disabled' : '') + '" onclick="' + (hasV ? '' : 'applyCompoundVFree(\'' + cd.name.replace(/'/g, "\\'") + '\')') + '"><span>' + escapeHtml(cd.name) + '</span><span>' + (hasV ? '✅ Куплен' : '▶ Выбрать (БЕСПЛАТНО)') + '</span></div>';
        });
    }
    html += '</div><button class="btn" style="width:100%;margin-top:10px;background:#e74c3c;" onclick="closeModal()">Отмена</button>';
    let el = document.getElementById("modalContent");
    if (el) el.innerHTML = html;
    el = document.getElementById("modalOverlay");
    if (el) el.style.display = "flex";
}

function applyCompoundVFree(name) {
    if (hasCompoundV[name]) return;
    hasCompoundV[name] = true;
    saveAll();
    renderAll();
    updatePlayerStats();
    closeModal();
    showFloatingText("💉 Препарат V: " + name + " (бесплатно)!", "#9b59b6");
}

// ★ ФИКС: renderPass() теперь сохраняет и восстанавливает скролл ★
function renderPass() {
    let container = document.getElementById("passContent");
    if (!container) return;
    
    // ★ СОХРАНЯЕМ ПОЗИЦИЮ СКРОЛЛА ДО ПЕРЕРИСОВКИ ★
    let oldTiersList = document.getElementById("passTiersList");
    let savedScroll = oldTiersList ? oldTiersList.scrollTop : _passScrollPosition;
    _passScrollPosition = savedScroll;
    
    let html = '';
    let nextExp = getPassExpNeeded(passData.currentTier);
    let progressPercent = passData.currentTier >= 60 ? 100 : Math.min(100, Math.floor((passData.passExp / nextExp) * 100));
    
    html += '<div style="text-align:center;margin-bottom:15px;">';
    html += '<div style="font-size:24px;font-weight:900;color:#ffd700;">🎫 МУЛЬТИВЕРС ПАСС</div>';
    html += '<div style="font-size:16px;font-weight:800;margin-top:5px;">Этап ' + passData.currentTier + ' из 60</div>';
    if (passData.currentTier < 60) {
        html += '<div style="margin-top:8px;font-size:13px;">Опыт: ' + passData.passExp + ' / ' + nextExp + '</div>';
        html += '<div style="background:rgba(0,0,0,0.5);border-radius:10px;margin:8px 0;height:12px;"><div style="width:' + progressPercent + '%;background:linear-gradient(90deg, #ffd700, #ff8c00);height:12px;border-radius:10px;transition:width 0.5s;"></div></div>';
    } else {
        html += '<div style="margin-top:8px;font-size:16px;color:#ffd700;font-weight:900;">🎉 ПАСС ПОЛНОСТЬЮ ЗАВЕРШЁН! 🎉</div>';
    }
    html += '<div style="font-size:12px;color:#aaa;">💡 Опыт начисляется за клики, победы и убийства боссов</div>';
    html += '</div>';
    
    html += '<div style="display:flex;flex-direction:column;gap:6px;max-height:400px;overflow-y:auto;padding-right:5px;" id="passTiersList">';
    for (let i = 0; i < passRewards.length; i++) {
        let tier = i + 1;
        let reward = passRewards[i];
        let unlocked = tier <= passData.currentTier || (mode === "moder" && moderUnlocked);
        let claimed = passData.claimedTiers.includes(tier);
        let isCurrent = tier === passData.currentTier;
        
        let bgColor = claimed ? 'rgba(46, 204, 113, 0.15)' : (unlocked ? (isCurrent ? 'rgba(245, 175, 25, 0.2)' : 'rgba(255,255,255,0.05)') : 'rgba(255,255,255,0.02)');
        let borderColor = claimed ? '#2ecc71' : (unlocked ? (isCurrent ? '#f5af19' : 'rgba(255,255,255,0.15)') : 'rgba(255,255,255,0.05)');
        let opacity = unlocked ? '1' : '0.4';
        
        html += '<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:' + bgColor + ';border:2px solid ' + borderColor + ';border-radius:14px;opacity:' + opacity + ';transition:all 0.2s;min-height:50px;">';
        html += '<div style="font-size:20px;min-width:30px;text-align:center;">' + reward.icon + '</div>';
        html += '<div style="flex:1;">';
        html += '<div style="font-weight:800;font-size:12px;">Этап ' + tier + ': ' + reward.name + '</div>';
        html += '</div>';
        if (claimed) {
            html += '<div style="font-size:16px;color:#2ecc71;">✅</div>';
        } else if (unlocked) {
            html += '<button class="btn btn-primary" style="padding:4px 12px;font-size:11px;cursor:pointer;pointer-events:auto;" onclick="event.stopPropagation();claimPassReward(' + tier + ')">Забрать</button>';
        } else {
            html += '<div style="font-size:16px;color:#aaa;">🔒</div>';
        }
        html += '</div>';
    }
    html += '</div>';
    
    container.innerHTML = html;
    
    // ★ ВОССТАНАВЛИВАЕМ СКРОЛЛ ПОСЛЕ ВСТАВКИ HTML ★
    let newTiersList = document.getElementById("passTiersList");
    if (newTiersList) {
        newTiersList.scrollTop = savedScroll;
        // Запоминаем позицию при скролле пользователем
        newTiersList.addEventListener('scroll', function() {
            _passScrollPosition = newTiersList.scrollTop;
        });
    }
}
